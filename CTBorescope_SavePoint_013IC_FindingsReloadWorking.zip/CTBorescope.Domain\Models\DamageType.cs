namespace CTBorescope.Domain.Models;

public static class DamageType
{
    public const string Crack =
        "Crack";

    public const string CoatingLoss =
        "Coating Loss";

    public const string Erosion =
        "Erosion";

    public const string Oxidation =
        "Oxidation";

    public const string Burn =
        "Burn";

    public const string Deposit =
        "Deposit";

    public const string ForeignObjectDamage =
        "Foreign Object Damage";

    public const string Unknown =
        "Unknown";
}
