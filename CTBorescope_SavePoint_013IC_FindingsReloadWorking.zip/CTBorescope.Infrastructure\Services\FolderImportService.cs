using System.Collections.Generic;
using System.IO;
using System.Linq;
using CTBorescope.Domain.Models;

namespace CTBorescope.Infrastructure.Services;

public class FolderImportService
{
    private static readonly string[] SupportedExtensions =
    {
        ".jpg",
        ".jpeg",
        ".png",
        ".bmp",
        ".tif",
        ".tiff"
    };

    public List<ImageRecord> ScanFolder(
        string rootFolder)
    {
        var images =
            new List<ImageRecord>();

        if (string.IsNullOrWhiteSpace(rootFolder))
        {
            return images;
        }

        if (!Directory.Exists(rootFolder))
        {
            return images;
        }

        var files =
            Directory
                .EnumerateFiles(
                    rootFolder,
                    "*.*",
                    SearchOption.AllDirectories)
                .Where(IsSupportedImage)
                .OrderBy(
                    file => file,
                    System.StringComparer.OrdinalIgnoreCase)
                .ToList();

        foreach (var file in files)
        {
            var fileInfo =
                new FileInfo(file);

            images.Add(
                new ImageRecord
                {
                    FileName =
                        fileInfo.Name,

                    FullPath =
                        fileInfo.FullName,

                    RelativeFolder =
                        Path.GetRelativePath(
                            rootFolder,
                            fileInfo.DirectoryName
                                ?? rootFolder),

                    CreatedDate =
                        fileInfo.CreationTime,

                    ModifiedDate =
                        fileInfo.LastWriteTime,

                    FileSizeBytes =
                        fileInfo.Length,

                    TimestampSource =
                        "Not evaluated",

                    MetadataStatus =
                        "Metadata pending",

                    ValidationResult =
                        "Pending validation"
                });
        }

        return images;
    }

    private static bool IsSupportedImage(
        string filePath)
    {
        var extension =
            Path.GetExtension(filePath);

        return SupportedExtensions.Contains(
            extension,
            System.StringComparer.OrdinalIgnoreCase);
    }
}