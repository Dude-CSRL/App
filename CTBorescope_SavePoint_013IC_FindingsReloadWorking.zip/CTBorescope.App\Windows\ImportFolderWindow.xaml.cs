using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using CTBorescope.Domain.Models;
using CTBorescope.Infrastructure.Services;
using CTBorescope.Reporting;

namespace CTBorescope.App.Windows;

public partial class ImportFolderWindow : Window
{
    private readonly ImportBuilderService _importBuilderService =
        new();

    private readonly InspectionReportGenerator _reportGenerator =
        new();

    private readonly PowerPointReportGenerator _powerPointGenerator =
        new();

    private ImportSummary? _currentSummary;

    public ImportFolderWindow()
    {
        InitializeComponent();
    }

    private void Browse_Click(
        object sender,
        RoutedEventArgs e)
    {
        var folder =
            FolderPathTextBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(folder))
        {
            ResultsTextBox.Text =
                "Enter the inspection folder path above.";

            return;
        }

        if (!Directory.Exists(folder))
        {
            ResultsTextBox.Text =
                "The selected inspection folder does not exist.";

            return;
        }

        System.Windows.Input.Mouse.OverrideCursor =
            System.Windows.Input.Cursors.Wait;

        try
        {
            _currentSummary =
                _importBuilderService.BuildSummary(folder);

            ResultsTextBox.Text =
                BuildResultsText(_currentSummary);
        }
        catch (Exception exception)
        {
            _currentSummary =
                null;

            ResultsTextBox.Text =
                "The inspection folder could not be processed." +
                Environment.NewLine +
                Environment.NewLine +
                exception.Message;
        }
        finally
        {
            System.Windows.Input.Mouse.OverrideCursor =
                null;
        }
    }

    private void GenerateReport_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (!EnsureInspectionImported())
        {
            return;
        }

        try
        {
            var reportPath =
                _reportGenerator.GenerateReport(
                    _currentSummary!);

            ShowCreatedFileMessage(
                "Text inspection report",
                reportPath);

            OpenContainingFolder(
                reportPath);
        }
        catch (Exception exception)
        {
            ShowGenerationError(
                "text inspection report",
                exception);
        }
    }

    private void GeneratePowerPoint_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (!EnsureInspectionImported())
        {
            return;
        }

        System.Windows.Input.Mouse.OverrideCursor =
            System.Windows.Input.Cursors.Wait;

        try
        {
            var powerPointPath =
                _powerPointGenerator.GeneratePowerPoint(
                    _currentSummary!);

            ShowCreatedFileMessage(
                "PowerPoint inspection report",
                powerPointPath);

            OpenGeneratedFile(
                powerPointPath);
        }
        catch (Exception exception)
        {
            ShowGenerationError(
                "PowerPoint inspection report",
                exception);
        }
        finally
        {
            System.Windows.Input.Mouse.OverrideCursor =
                null;
        }
    }

    private void ReviewFindings_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (!EnsureInspectionImported())
        {
            return;
        }

        var window =
            new FindingReviewWindow(
                _currentSummary!);

        window.Owner =
            this;

        window.ShowDialog();
    }

    private bool EnsureInspectionImported()
    {
        if (_currentSummary is not null)
        {
            return true;
        }

        MessageBox.Show(
            "Import an inspection folder before generating a report.",
            "CT Borescope Process Tool",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        return false;
    }

    private static void ShowCreatedFileMessage(
        string reportType,
        string reportPath)
    {
        MessageBox.Show(
            $"{reportType} created successfully." +
            Environment.NewLine +
            Environment.NewLine +
            reportPath,
            "CT Borescope Process Tool",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private static void ShowGenerationError(
        string reportType,
        Exception exception)
    {
        MessageBox.Show(
            $"The {reportType} could not be generated." +
            Environment.NewLine +
            Environment.NewLine +
            exception.Message,
            "CT Borescope Process Tool",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }

    private static void OpenGeneratedFile(
        string filePath)
    {
        if (!File.Exists(filePath))
        {
            return;
        }

        Process.Start(
            new ProcessStartInfo
            {
                FileName =
                    filePath,

                UseShellExecute =
                    true
            });
    }

    private static void OpenContainingFolder(
        string filePath)
    {
        var folder =
            Path.GetDirectoryName(filePath);

        if (string.IsNullOrWhiteSpace(folder))
        {
            return;
        }

        if (!Directory.Exists(folder))
        {
            return;
        }

        Process.Start(
            new ProcessStartInfo
            {
                FileName =
                    folder,

                UseShellExecute =
                    true
            });
    }

    private static string BuildResultsText(
        ImportSummary summary)
    {
        var text =
            new StringBuilder();

        var allImages =
            summary.Areas
                .SelectMany(area => area.Images)
                .ToList();

        var imagesWithExif =
            allImages.Count(
                image => image.HasExifDateTaken);

        var imagesWithoutExif =
            allImages.Count(
                image => !image.HasExifDateTaken);

        text.AppendLine(
            $"Inspection: {summary.InspectionName}");

        text.AppendLine();

        text.AppendLine(
            $"Areas Found: {summary.AreaCount}");

        text.AppendLine(
            $"Images Found: {summary.ImageCount}");

        text.AppendLine(
            $"Videos Found: {summary.VideoCount}");

        text.AppendLine(
            $"Photos With EXIF Date Taken: {imagesWithExif}");

        text.AppendLine(
            $"Photos Missing EXIF Date Taken: {imagesWithoutExif}");

        text.AppendLine();

        text.AppendLine(
            $"First Photo: {FormatDate(summary.FirstPhoto)}");

        text.AppendLine(
            $"Last Photo: {FormatDate(summary.LastPhoto)}");

        text.AppendLine(
            $"Inspection Duration: {FormatDuration(summary.Duration)}");

        text.AppendLine();

        text.AppendLine(
            "Inspection Sequence:");

        foreach (var area in summary.Areas)
        {
            text.AppendLine();

            text.AppendLine(
                $"#{area.InspectionOrder} {area.AreaName}");

            text.AppendLine(
                $"  Images: {area.ImageCount}");

            text.AppendLine(
                $"  Videos: {area.VideoCount}");

            text.AppendLine(
                $"  First Photo: {FormatDate(area.FirstPhoto)}");

            text.AppendLine(
                $"  Last Photo: {FormatDate(area.LastPhoto)}");

            text.AppendLine(
                $"  Photo Duration: " +
                $"{FormatDuration(area.PhotoDuration)}");

            if (area.VideoCount > 0)
            {
                text.AppendLine(
                    "  Video Classification: " +
                    "Supplemental Documentation");

                text.AppendLine(
                    "  AI Image Review: Videos excluded");
            }
        }

        return text.ToString();
    }

    private static string FormatDate(
        DateTime? date)
    {
        return date.HasValue
            ? date.Value.ToString(
                "MM/dd/yyyy h:mm:ss tt")
            : "Not available";
    }

    private static string FormatDuration(
        TimeSpan? duration)
    {
        if (!duration.HasValue)
        {
            return "Not available";
        }

        var value =
            duration.Value;

        return
            $"{(int)value.TotalHours}h " +
            $"{value.Minutes}m " +
            $"{value.Seconds}s";
    }

    private void Close_Click(
        object sender,
        RoutedEventArgs e)
    {
        Close();
    }
}