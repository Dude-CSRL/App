using System;

namespace CTBorescope.Domain.Models;

public class FindingRecord
{
    public Guid FindingId { get; set; } =
        Guid.NewGuid();

    public string InspectionArea { get; set; } =
        "";

    public string Component { get; set; } =
        "";

    public string SourceImagePath { get; set; } =
        "";

    public string SourceImageFileName { get; set; } =
        "";

    public string DamageType { get; set; } =
        "Unknown";

    public string Severity { get; set; } =
        "Unclassified";

    public int ConfidencePercent { get; set; }

    public string Description { get; set; } =
        "";

    public double SelectionX { get; set; }

    public double SelectionY { get; set; }

    public double SelectionWidth { get; set; }

    public double SelectionHeight { get; set; }

    public string ReviewerDisposition { get; set; } =
        "Pending Review";

    public string ReviewerComments { get; set; } =
        "";

    public bool ReviewerConfirmed { get; set; }

    public DateTime CreatedDate { get; set; } =
        DateTime.Now;

    public DateTime? ReviewedDate { get; set; }

    public string AnnotatedImagePath { get; set; } =
        "";

    public string ZoomImagePath { get; set; } =
        "";

    public bool HasValidSelection =>
        SelectionWidth > 0 &&
        SelectionHeight > 0;
}