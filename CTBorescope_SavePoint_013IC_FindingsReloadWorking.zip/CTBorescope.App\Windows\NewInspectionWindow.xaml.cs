using System.Windows;

namespace CTBorescope.App.Windows;

public partial class NewInspectionWindow : Window
{
    public NewInspectionWindow()
    {
        InitializeComponent();
    }

    private void Create_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "Inspection Project Created",
            "CT Borescope Process Tool");
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}