﻿using System.Windows;
using CTBorescope.App.Windows;

namespace CTBorescope.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void NewInspection_Click(object sender, RoutedEventArgs e)
    {
        var window = new NewInspectionWindow();

        window.Owner = this;

        window.ShowDialog();
    }

    private void ImportFolder_Click(object sender, RoutedEventArgs e)
    {
        var window = new ImportFolderWindow();

        window.Owner = this;

        window.ShowDialog();
    }
}