﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace CTBorescope.Reporting;

public sealed class ImageEvidenceResult
{
    public string AnnotatedImagePath { get; init; } =
        "";

    public string ZoomImagePath { get; init; } =
        "";
}

public class ImageAnnotationService
{
    public ImageEvidenceResult CreateFindingEvidence(
        string sourceImagePath,
        string outputFolder,
        Guid findingId,
        double selectionX,
        double selectionY,
        double selectionWidth,
        double selectionHeight,
        double displayWidth,
        double displayHeight)
    {
        if (string.IsNullOrWhiteSpace(
                sourceImagePath))
        {
            throw new ArgumentException(
                "The source image path is required.",
                nameof(sourceImagePath));
        }

        if (!File.Exists(
                sourceImagePath))
        {
            throw new FileNotFoundException(
                "The source image could not be found.",
                sourceImagePath);
        }

        if (selectionWidth <= 0 ||
            selectionHeight <= 0)
        {
            throw new InvalidOperationException(
                "The selected finding region is invalid.");
        }

        if (displayWidth <= 0 ||
            displayHeight <= 0)
        {
            throw new InvalidOperationException(
                "The image preview dimensions are invalid.");
        }

        Directory.CreateDirectory(
            outputFolder);

        using var sourceImage =
            Image.FromFile(
                sourceImagePath);

        using var sourceBitmap =
            new Bitmap(
                sourceImage);

        var sourceRectangle =
            ConvertDisplaySelectionToSourceRectangle(
                sourceBitmap.Width,
                sourceBitmap.Height,
                selectionX,
                selectionY,
                selectionWidth,
                selectionHeight,
                displayWidth,
                displayHeight);

        var safeSourceName =
            CreateSafeFileName(
                Path.GetFileNameWithoutExtension(
                    sourceImagePath));

        var shortFindingId =
            findingId
                .ToString("N")
                .Substring(0, 8);

        var annotatedImagePath =
            Path.Combine(
                outputFolder,
                $"{safeSourceName}_" +
                $"{shortFindingId}_Annotated.jpg");

        var zoomImagePath =
            Path.Combine(
                outputFolder,
                $"{safeSourceName}_" +
                $"{shortFindingId}_Zoom.jpg");

        CreateAnnotatedImage(
            sourceBitmap,
            sourceRectangle,
            annotatedImagePath);

        CreateZoomImage(
            sourceBitmap,
            sourceRectangle,
            zoomImagePath);

        return new ImageEvidenceResult
        {
            AnnotatedImagePath =
                annotatedImagePath,

            ZoomImagePath =
                zoomImagePath
        };
    }

    private static Rectangle ConvertDisplaySelectionToSourceRectangle(
        int sourceWidth,
        int sourceHeight,
        double selectionX,
        double selectionY,
        double selectionWidth,
        double selectionHeight,
        double displayWidth,
        double displayHeight)
    {
        var widthScale =
            displayWidth /
            sourceWidth;

        var heightScale =
            displayHeight /
            sourceHeight;

        var imageScale =
            Math.Min(
                widthScale,
                heightScale);

        var renderedImageWidth =
            sourceWidth *
            imageScale;

        var renderedImageHeight =
            sourceHeight *
            imageScale;

        var horizontalOffset =
            (displayWidth -
             renderedImageWidth) /
            2.0;

        var verticalOffset =
            (displayHeight -
             renderedImageHeight) /
            2.0;

        var displayLeft =
            Math.Max(
                selectionX,
                horizontalOffset);

        var displayTop =
            Math.Max(
                selectionY,
                verticalOffset);

        var displayRight =
            Math.Min(
                selectionX +
                selectionWidth,
                horizontalOffset +
                renderedImageWidth);

        var displayBottom =
            Math.Min(
                selectionY +
                selectionHeight,
                verticalOffset +
                renderedImageHeight);

        if (displayRight <= displayLeft ||
            displayBottom <= displayTop)
        {
            throw new InvalidOperationException(
                "The selected rectangle does not overlap the image.");
        }

        var sourceX =
            (displayLeft -
             horizontalOffset) /
            imageScale;

        var sourceY =
            (displayTop -
             verticalOffset) /
            imageScale;

        var sourceSelectionWidth =
            (displayRight -
             displayLeft) /
            imageScale;

        var sourceSelectionHeight =
            (displayBottom -
             displayTop) /
            imageScale;

        var left =
            Math.Clamp(
                (int)Math.Round(sourceX),
                0,
                sourceWidth - 1);

        var top =
            Math.Clamp(
                (int)Math.Round(sourceY),
                0,
                sourceHeight - 1);

        var width =
            Math.Clamp(
                (int)Math.Round(
                    sourceSelectionWidth),
                1,
                sourceWidth - left);

        var height =
            Math.Clamp(
                (int)Math.Round(
                    sourceSelectionHeight),
                1,
                sourceHeight - top);

        return new Rectangle(
            left,
            top,
            width,
            height);
    }

    private static void CreateAnnotatedImage(
        Bitmap sourceBitmap,
        Rectangle sourceRectangle,
        string annotatedImagePath)
    {
        using var annotatedBitmap =
            new Bitmap(
                sourceBitmap.Width,
                sourceBitmap.Height,
                PixelFormat.Format24bppRgb);

        annotatedBitmap.SetResolution(
            sourceBitmap.HorizontalResolution,
            sourceBitmap.VerticalResolution);

        using var graphics =
            Graphics.FromImage(
                annotatedBitmap);

        graphics.SmoothingMode =
            SmoothingMode.AntiAlias;

        graphics.InterpolationMode =
            InterpolationMode.HighQualityBicubic;

        graphics.PixelOffsetMode =
            PixelOffsetMode.HighQuality;

        graphics.DrawImage(
            sourceBitmap,
            0,
            0,
            sourceBitmap.Width,
            sourceBitmap.Height);

        var lineThickness =
            Math.Max(
                4.0f,
                Math.Min(
                    sourceBitmap.Width,
                    sourceBitmap.Height) /
                250.0f);

        using var rectanglePen =
            new Pen(
                Color.Red,
                lineThickness);

        graphics.DrawRectangle(
            rectanglePen,
            sourceRectangle);

        DrawFindingArrow(
            graphics,
            sourceBitmap.Size,
            sourceRectangle,
            lineThickness);

        SaveJpeg(
            annotatedBitmap,
            annotatedImagePath,
            92L);
    }

    private static void DrawFindingArrow(
        Graphics graphics,
        Size imageSize,
        Rectangle sourceRectangle,
        float lineThickness)
    {
        var targetX =
            sourceRectangle.Left +
            (sourceRectangle.Width / 2);

        var targetY =
            sourceRectangle.Top +
            (sourceRectangle.Height / 2);

        var arrowStartX =
            sourceRectangle.Left >
            imageSize.Width / 2
                ? sourceRectangle.Left -
                  Math.Max(
                      40,
                      sourceRectangle.Width / 3)
                : sourceRectangle.Right +
                  Math.Max(
                      40,
                      sourceRectangle.Width / 3);

        var arrowStartY =
            Math.Max(
                0,
                sourceRectangle.Top -
                Math.Max(
                    40,
                    sourceRectangle.Height / 3));

        arrowStartX =
            Math.Clamp(
                arrowStartX,
                0,
                imageSize.Width - 1);

        arrowStartY =
            Math.Clamp(
                arrowStartY,
                0,
                imageSize.Height - 1);

        using var arrowPen =
            new Pen(
                Color.Red,
                lineThickness);

        using var arrowCap =
            new AdjustableArrowCap(
                lineThickness * 2.5f,
                lineThickness * 3.5f,
                true);

        arrowPen.CustomEndCap =
            arrowCap;

        graphics.DrawLine(
            arrowPen,
            arrowStartX,
            arrowStartY,
            targetX,
            targetY);
    }

    private static void CreateZoomImage(
        Bitmap sourceBitmap,
        Rectangle sourceRectangle,
        string zoomImagePath)
    {
        var horizontalPadding =
            Math.Max(
                10,
                (int)Math.Round(
                    sourceRectangle.Width *
                    0.15));

        var verticalPadding =
            Math.Max(
                10,
                (int)Math.Round(
                    sourceRectangle.Height *
                    0.15));

        var zoomRectangle =
            Rectangle.FromLTRB(
                Math.Max(
                    0,
                    sourceRectangle.Left -
                    horizontalPadding),

                Math.Max(
                    0,
                    sourceRectangle.Top -
                    verticalPadding),

                Math.Min(
                    sourceBitmap.Width,
                    sourceRectangle.Right +
                    horizontalPadding),

                Math.Min(
                    sourceBitmap.Height,
                    sourceRectangle.Bottom +
                    verticalPadding));

        using var zoomBitmap =
            new Bitmap(
                zoomRectangle.Width,
                zoomRectangle.Height,
                PixelFormat.Format24bppRgb);

        zoomBitmap.SetResolution(
            sourceBitmap.HorizontalResolution,
            sourceBitmap.VerticalResolution);

        using var graphics =
            Graphics.FromImage(
                zoomBitmap);

        graphics.InterpolationMode =
            InterpolationMode.HighQualityBicubic;

        graphics.PixelOffsetMode =
            PixelOffsetMode.HighQuality;

        graphics.DrawImage(
            sourceBitmap,
            new Rectangle(
                0,
                0,
                zoomBitmap.Width,
                zoomBitmap.Height),
            zoomRectangle,
            GraphicsUnit.Pixel);

        var findingWithinZoom =
            new Rectangle(
                sourceRectangle.Left -
                zoomRectangle.Left,
                sourceRectangle.Top -
                zoomRectangle.Top,
                sourceRectangle.Width,
                sourceRectangle.Height);

        var lineThickness =
            Math.Max(
                3.0f,
                Math.Min(
                    zoomBitmap.Width,
                    zoomBitmap.Height) /
                150.0f);

        using var rectanglePen =
            new Pen(
                Color.Red,
                lineThickness);

        graphics.DrawRectangle(
            rectanglePen,
            findingWithinZoom);

        SaveJpeg(
            zoomBitmap,
            zoomImagePath,
            95L);
    }

    private static void SaveJpeg(
        Bitmap bitmap,
        string outputPath,
        long quality)
    {
        var jpegCodec =
            ImageCodecInfo
                .GetImageEncoders()
                .FirstOrDefault(
                    encoder =>
                        encoder.FormatID ==
                        ImageFormat.Jpeg.Guid);

        if (jpegCodec is null)
        {
            bitmap.Save(
                outputPath,
                ImageFormat.Jpeg);

            return;
        }

        using var encoderParameters =
            new EncoderParameters(1);

        encoderParameters.Param[0] =
            new EncoderParameter(
                Encoder.Quality,
                quality);

        bitmap.Save(
            outputPath,
            jpegCodec,
            encoderParameters);
    }

    private static string CreateSafeFileName(
        string value)
    {
        var safeValue =
            value;

        foreach (var invalidCharacter
                 in Path.GetInvalidFileNameChars())
        {
            safeValue =
                safeValue.Replace(
                    invalidCharacter,
                    '_');
        }

        return string.IsNullOrWhiteSpace(
            safeValue)
                ? "Finding"
                : safeValue;
    }
}