using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using CTBorescope.Domain.Models;

namespace CTBorescope.Data.Repositories;

public class FindingRepository
{
    public void SaveFindings(
        string jsonPath,
        List<FindingRecord> findings)
    {
        var options =
            new JsonSerializerOptions
            {
                WriteIndented = true
            };

        var json =
            JsonSerializer.Serialize(
                findings,
                options);

        File.WriteAllText(
            jsonPath,
            json);
    }

    public List<FindingRecord> LoadFindings(
        string jsonPath)
    {
        if (!File.Exists(
                jsonPath))
        {
            return new List<FindingRecord>();
        }

        var json =
            File.ReadAllText(
                jsonPath);

        return JsonSerializer.Deserialize<
                   List<FindingRecord>>(
                       json)
               ?? new List<FindingRecord>();
    }
}
