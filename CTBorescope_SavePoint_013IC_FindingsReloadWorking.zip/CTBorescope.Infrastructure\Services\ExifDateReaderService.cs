using System;
using System.Globalization;
using System.IO;
using System.Windows.Media.Imaging;

namespace CTBorescope.Infrastructure.Services;

public class ExifDateReaderService
{
    private static readonly string[] SupportedDateFormats =
    {
        "yyyy:MM:dd HH:mm:ss",
        "yyyy-MM-dd HH:mm:ss",
        "MM/dd/yyyy HH:mm:ss",
        "M/d/yyyy h:mm:ss tt",
        "M/d/yyyy h:mm tt",
        "MM/dd/yyyy h:mm:ss tt",
        "MM/dd/yyyy h:mm tt"
    };

    public DateTime? ReadDateTaken(string imagePath)
    {
        if (string.IsNullOrWhiteSpace(imagePath))
        {
            return null;
        }

        if (!File.Exists(imagePath))
        {
            return null;
        }

        try
        {
            using var stream = new FileStream(
                imagePath,
                FileMode.Open,
                FileAccess.Read,
                FileShare.ReadWrite);

            var decoder = BitmapDecoder.Create(
                stream,
                BitmapCreateOptions.PreservePixelFormat,
                BitmapCacheOption.OnLoad);

            if (decoder.Frames.Count == 0)
            {
                return null;
            }

            if (decoder.Frames[0].Metadata
                is not BitmapMetadata metadata)
            {
                return null;
            }

            var dateTakenText =
                metadata.DateTaken;

            if (string.IsNullOrWhiteSpace(dateTakenText))
            {
                dateTakenText =
                    ReadExifDateTimeOriginal(metadata);
            }

            return ParseDateTaken(dateTakenText);
        }
        catch
        {
            return null;
        }
    }

    private static string? ReadExifDateTimeOriginal(
        BitmapMetadata metadata)
    {
        try
        {
            const string exifDateTimeOriginalQuery =
                "/app1/ifd/exif/{uint=36867}";

            if (!metadata.ContainsQuery(
                    exifDateTimeOriginalQuery))
            {
                return null;
            }

            return metadata
                .GetQuery(exifDateTimeOriginalQuery)?
                .ToString();
        }
        catch
        {
            return null;
        }
    }

    private static DateTime? ParseDateTaken(
        string? dateTakenText)
    {
        if (string.IsNullOrWhiteSpace(dateTakenText))
        {
            return null;
        }

        var cleanedText =
            dateTakenText
                .Trim()
                .TrimEnd('\0');

        foreach (var format in SupportedDateFormats)
        {
            if (DateTime.TryParseExact(
                    cleanedText,
                    format,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.AllowWhiteSpaces,
                    out var exactDate))
            {
                return exactDate;
            }
        }

        if (DateTime.TryParse(
                cleanedText,
                CultureInfo.CurrentCulture,
                DateTimeStyles.AllowWhiteSpaces,
                out var currentCultureDate))
        {
            return currentCultureDate;
        }

        if (DateTime.TryParse(
                cleanedText,
                CultureInfo.InvariantCulture,
                DateTimeStyles.AllowWhiteSpaces,
                out var invariantDate))
        {
            return invariantDate;
        }

        return null;
    }
}