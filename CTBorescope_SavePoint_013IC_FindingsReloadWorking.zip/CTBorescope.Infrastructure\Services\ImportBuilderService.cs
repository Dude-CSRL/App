using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CTBorescope.Domain.Models;

namespace CTBorescope.Infrastructure.Services;

public class ImportBuilderService
{
    private static readonly string[] SupportedImageExtensions =
    {
        ".jpg",
        ".jpeg",
        ".png",
        ".bmp",
        ".tif",
        ".tiff"
    };

    private static readonly string[] SupportedVideoExtensions =
    {
        ".mp4",
        ".mov",
        ".avi",
        ".wmv",
        ".m4v",
        ".mpg",
        ".mpeg"
    };

    private static readonly string[] ExcludedFolderNames =
    {
        "CT Borescope Reports",
        "Reports",
        "Report",
        "Output",
        "Generated Reports"
    };

    private readonly ExifDateReaderService _exifDateReaderService =
        new();

    public ImportSummary BuildSummary(
        string rootFolder)
    {
        var summary =
            new ImportSummary
            {
                InspectionName =
                    GetInspectionName(rootFolder),

                RootFolder =
                    rootFolder
            };

        if (string.IsNullOrWhiteSpace(rootFolder))
        {
            return summary;
        }

        if (!Directory.Exists(rootFolder))
        {
            return summary;
        }

        var areaFolders =
            Directory
                .GetDirectories(rootFolder)
                .Where(
                    folder => !IsExcludedFolder(folder))
                .OrderBy(
                    folder => Path.GetFileName(folder),
                    StringComparer.OrdinalIgnoreCase)
                .ToList();

        foreach (var areaFolder in areaFolders)
        {
            var area =
                BuildInspectionArea(
                    rootFolder,
                    areaFolder);

            if (area.ImageCount == 0 &&
                area.VideoCount == 0)
            {
                continue;
            }

            summary.Areas.Add(area);
        }

        AssignInspectionOrder(
            summary.Areas);

        summary.AreaCount =
            summary.Areas.Count;

        summary.ImageCount =
            summary.Areas.Sum(
                area => area.ImageCount);

        summary.VideoCount =
            summary.Areas.Sum(
                area => area.VideoCount);

        var inspectionDates =
            summary.Areas
                .SelectMany(
                    area => area.Images)
                .Where(
                    image => image.DateTaken.HasValue)
                .Select(
                    image => image.DateTaken!.Value)
                .OrderBy(
                    date => date)
                .ToList();

        if (inspectionDates.Count > 0)
        {
            summary.FirstPhoto =
                inspectionDates.First();

            summary.LastPhoto =
                inspectionDates.Last();
        }

        return summary;
    }

    private InspectionArea BuildInspectionArea(
        string rootFolder,
        string areaFolder)
    {
        var area =
            new InspectionArea
            {
                AreaName =
                    Path.GetFileName(areaFolder)
            };

        var allFiles =
            Directory
                .EnumerateFiles(
                    areaFolder,
                    "*.*",
                    SearchOption.AllDirectories)
                .Where(
                    file => !IsFileInsideExcludedFolder(
                        rootFolder,
                        file))
                .OrderBy(
                    path => path,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();

        var imagePaths =
            allFiles
                .Where(IsSupportedImage)
                .ToList();

        var videoPaths =
            allFiles
                .Where(IsSupportedVideo)
                .ToList();

        foreach (var imagePath in imagePaths)
        {
            area.Images.Add(
                BuildImageRecord(
                    rootFolder,
                    areaFolder,
                    imagePath));
        }

        foreach (var videoPath in videoPaths)
        {
            area.Videos.Add(
                BuildVideoRecord(
                    rootFolder,
                    areaFolder,
                    videoPath));
        }

        area.ImageCount =
            area.Images.Count;

        area.VideoCount =
            area.Videos.Count;

        var areaDates =
            area.Images
                .Where(
                    image => image.DateTaken.HasValue)
                .Select(
                    image => image.DateTaken!.Value)
                .OrderBy(
                    date => date)
                .ToList();

        if (areaDates.Count > 0)
        {
            area.FirstPhoto =
                areaDates.First();

            area.LastPhoto =
                areaDates.Last();
        }

        return area;
    }

    private ImageRecord BuildImageRecord(
        string rootFolder,
        string areaFolder,
        string imagePath)
    {
        var fileInfo =
            new FileInfo(imagePath);

        var dateTaken =
            _exifDateReaderService
                .ReadDateTaken(imagePath);

        return new ImageRecord
        {
            FileName =
                fileInfo.Name,

            FullPath =
                fileInfo.FullName,

            RelativeFolder =
                Path.GetRelativePath(
                    rootFolder,
                    fileInfo.DirectoryName
                        ?? areaFolder),

            DateTaken =
                dateTaken,

            CreatedDate =
                fileInfo.CreationTime,

            ModifiedDate =
                fileInfo.LastWriteTime,

            FileSizeBytes =
                fileInfo.Length,

            TimestampSource =
                dateTaken.HasValue
                    ? "EXIF Date Taken"
                    : "Unavailable",

            MetadataStatus =
                dateTaken.HasValue
                    ? "EXIF Date Taken found"
                    : "EXIF Date Taken not found",

            TimestampValidated =
                false,

            ValidationResult =
                dateTaken.HasValue
                    ? "Pending timestamp validation"
                    : "No EXIF Date Taken value"
        };
    }

    private static VideoRecord BuildVideoRecord(
        string rootFolder,
        string areaFolder,
        string videoPath)
    {
        var fileInfo =
            new FileInfo(videoPath);

        return new VideoRecord
        {
            FileName =
                fileInfo.Name,

            FullPath =
                fileInfo.FullName,

            RelativeFolder =
                Path.GetRelativePath(
                    rootFolder,
                    fileInfo.DirectoryName
                        ?? areaFolder),

            FileExtension =
                fileInfo.Extension,

            CreatedDate =
                fileInfo.CreationTime,

            ModifiedDate =
                fileInfo.LastWriteTime,

            FileSizeBytes =
                fileInfo.Length,

            EvidenceCategory =
                "Supplemental Documentation",

            IncludeInAiImageReview =
                false
        };
    }

    private static void AssignInspectionOrder(
        List<InspectionArea> areas)
    {
        var orderedAreas =
            areas
                .OrderBy(
                    area =>
                        area.FirstPhoto.HasValue
                            ? 0
                            : 1)
                .ThenBy(
                    area =>
                        area.FirstPhoto
                        ?? DateTime.MaxValue)
                .ThenBy(
                    area => area.AreaName,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();

        for (var index = 0;
             index < orderedAreas.Count;
             index++)
        {
            orderedAreas[index].InspectionOrder =
                index + 1;
        }

        areas.Clear();

        areas.AddRange(
            orderedAreas);
    }

    private static bool IsExcludedFolder(
        string folderPath)
    {
        var folderName =
            Path.GetFileName(
                folderPath.TrimEnd(
                    Path.DirectorySeparatorChar,
                    Path.AltDirectorySeparatorChar));

        return ExcludedFolderNames.Contains(
            folderName,
            StringComparer.OrdinalIgnoreCase);
    }

    private static bool IsFileInsideExcludedFolder(
        string rootFolder,
        string filePath)
    {
        var relativePath =
            Path.GetRelativePath(
                rootFolder,
                filePath);

        var pathParts =
            relativePath.Split(
                new[]
                {
                    Path.DirectorySeparatorChar,
                    Path.AltDirectorySeparatorChar
                },
                StringSplitOptions.RemoveEmptyEntries);

        return pathParts.Any(
            part =>
                ExcludedFolderNames.Contains(
                    part,
                    StringComparer.OrdinalIgnoreCase));
    }

    private static bool IsSupportedImage(
        string filePath)
    {
        var extension =
            Path.GetExtension(filePath);

        return SupportedImageExtensions.Contains(
            extension,
            StringComparer.OrdinalIgnoreCase);
    }

    private static bool IsSupportedVideo(
        string filePath)
    {
        var extension =
            Path.GetExtension(filePath);

        return SupportedVideoExtensions.Contains(
            extension,
            StringComparer.OrdinalIgnoreCase);
    }

    private static string GetInspectionName(
        string rootFolder)
    {
        if (string.IsNullOrWhiteSpace(rootFolder))
        {
            return "";
        }

        var trimmedFolder =
            rootFolder.TrimEnd(
                Path.DirectorySeparatorChar,
                Path.AltDirectorySeparatorChar);

        return Path.GetFileName(
            trimmedFolder);
    }
}