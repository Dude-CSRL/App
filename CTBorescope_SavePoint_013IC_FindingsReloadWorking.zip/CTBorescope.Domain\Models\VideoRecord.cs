namespace CTBorescope.Domain.Models;

public class VideoRecord
{
    public string FileName { get; set; } = "";

    public string FullPath { get; set; } = "";

    public string RelativeFolder { get; set; } = "";

    public string FileExtension { get; set; } = "";

    public DateTime CreatedDate { get; set; }

    public DateTime ModifiedDate { get; set; }

    public long FileSizeBytes { get; set; }

    public string EvidenceCategory { get; set; } =
        "Supplemental Documentation";

    public bool IncludeInAiImageReview { get; set; } =
        false;
}