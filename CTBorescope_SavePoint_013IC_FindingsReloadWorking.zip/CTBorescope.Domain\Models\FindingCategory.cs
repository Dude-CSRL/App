namespace CTBorescope.Domain.Models;

public static class FindingCategory
{
    public const string NoIssue =
        "No Issue";

    public const string Monitor =
        "Monitor";

    public const string RepairRecommended =
        "Repair Recommended";

    public const string ImmediateAttention =
        "Immediate Attention";
}
