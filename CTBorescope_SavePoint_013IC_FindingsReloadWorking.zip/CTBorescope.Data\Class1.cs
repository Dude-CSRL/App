﻿namespace CTBorescope.Data;

public class Class1
{

}
