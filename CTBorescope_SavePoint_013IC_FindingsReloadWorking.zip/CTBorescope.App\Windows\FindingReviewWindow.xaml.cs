﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using CTBorescope.Domain.Models;
using CTBorescope.Reporting;
using CTBorescope.Data.Repositories;

namespace CTBorescope.App.Windows;

public partial class FindingReviewWindow : Window
{
    private readonly ImportSummary _summary;

    private readonly List<FindingRecord> _findings =
        new();

    private readonly ImageAnnotationService
        _imageAnnotationService =
            new();
            
    private readonly FindingRepository
        _findingRepository =
            new();

    private InspectionArea? _selectedArea;

    private ImageRecord? _selectedImage;

    private Point _startPoint;

    private bool _isDragging;

    public FindingReviewWindow(
        ImportSummary summary)
    {
        InitializeComponent();

        _summary =
            summary;

        LoadInspectionAreas();
        LoadExistingFindings();
    }

    private void LoadInspectionAreas()
    {
        AreaListBox.Items.Clear();

        foreach (var area in _summary.Areas)
        {
            AreaListBox.Items.Add(
                $"#{area.InspectionOrder} {area.AreaName}");
        }
    }

    private void LoadExistingFindings()
    {
        _findings.Clear();

        FindingsListBox.Items.Clear();

        var loadedFindingIds =
            new HashSet<Guid>();

        foreach (var area in _summary.Areas)
        {
            var firstImage =
                area.Images.FirstOrDefault();

            if (firstImage is null)
            {
                continue;
            }

            var areaFolder =
                Path.GetDirectoryName(
                    firstImage.FullPath);

            if (string.IsNullOrWhiteSpace(
                    areaFolder))
            {
                continue;
            }

            var findingsJsonPath =
                Path.Combine(
                    areaFolder,
                    "CT Borescope Reports",
                    "Findings.json");

            var areaFindings =
                _findingRepository.LoadFindings(
                    findingsJsonPath);

            foreach (var finding in areaFindings)
            {
                if (!loadedFindingIds.Add(
                        finding.FindingId))
                {
                    continue;
                }

                _findings.Add(
                    finding);

                FindingsListBox.Items.Add(
                    BuildFindingDisplayText(
                        finding,
                        _findings.Count));
            }
        }
    }
    private void AreaListBox_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        ImageListBox.Items.Clear();

        PreviewImage.Source =
            null;

        _selectedImage =
            null;

        ResetSelection();

        if (AreaListBox.SelectedIndex < 0)
        {
            _selectedArea =
                null;

            ImageStatusTextBlock.Text =
                "Select an Inspection Area";

            return;
        }

        _selectedArea =
            _summary.Areas[
                AreaListBox.SelectedIndex];

        foreach (var image in _selectedArea.Images)
        {
            ImageListBox.Items.Add(
                image.FileName);
        }

        ImageStatusTextBlock.Text =
            $"{_selectedArea.AreaName}\n" +
            $"{_selectedArea.ImageCount} Images\n" +
            $"{_selectedArea.VideoCount} Videos";

        ImageStatusTextBlock.Visibility =
            Visibility.Visible;
    }

    private void ImageListBox_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        ResetSelection();

        if (_selectedArea is null)
        {
            return;
        }

        if (ImageListBox.SelectedIndex < 0)
        {
            _selectedImage =
                null;

            return;
        }

        _selectedImage =
            _selectedArea.Images[
                ImageListBox.SelectedIndex];

        try
        {
            var bitmap =
                new BitmapImage();

            bitmap.BeginInit();

            bitmap.UriSource =
                new Uri(
                    _selectedImage.FullPath);

            bitmap.CacheOption =
                BitmapCacheOption.OnLoad;

            bitmap.EndInit();

            bitmap.Freeze();

            PreviewImage.Source =
                bitmap;

            ImageStatusTextBlock.Text =
                _selectedImage.FileName;

            ImageStatusTextBlock.Visibility =
                Visibility.Collapsed;
        }
        catch (Exception exception)
        {
            PreviewImage.Source =
                null;

            ImageStatusTextBlock.Text =
                exception.Message;

            ImageStatusTextBlock.Visibility =
                Visibility.Visible;
        }
    }

    private void SelectionCanvas_MouseLeftButtonDown(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_selectedImage is null)
        {
            return;
        }

        _isDragging =
            true;

        _startPoint =
            e.GetPosition(
                SelectionCanvas);

        Canvas.SetLeft(
            SelectionRectangle,
            _startPoint.X);

        Canvas.SetTop(
            SelectionRectangle,
            _startPoint.Y);

        SelectionRectangle.Width =
            0;

        SelectionRectangle.Height =
            0;

        SelectionRectangle.Visibility =
            Visibility.Visible;

        SelectionCanvas.CaptureMouse();
    }

    private void SelectionCanvas_MouseMove(
        object sender,
        MouseEventArgs e)
    {
        if (!_isDragging)
        {
            return;
        }

        var currentPoint =
            e.GetPosition(
                SelectionCanvas);

        var left =
            Math.Min(
                _startPoint.X,
                currentPoint.X);

        var top =
            Math.Min(
                _startPoint.Y,
                currentPoint.Y);

        var width =
            Math.Abs(
                currentPoint.X -
                _startPoint.X);

        var height =
            Math.Abs(
                currentPoint.Y -
                _startPoint.Y);

        Canvas.SetLeft(
            SelectionRectangle,
            left);

        Canvas.SetTop(
            SelectionRectangle,
            top);

        SelectionRectangle.Width =
            width;

        SelectionRectangle.Height =
            height;

        UpdateCoordinateDisplay(
            left,
            top,
            width,
            height);
    }

    private void SelectionCanvas_MouseLeftButtonUp(
        object sender,
        MouseButtonEventArgs e)
    {
        _isDragging =
            false;

        SelectionCanvas.ReleaseMouseCapture();

        UpdateCoordinateDisplay(
            GetRectangleLeft(),
            GetRectangleTop(),
            SelectionRectangle.Width,
            SelectionRectangle.Height);
    }

    private void CreateFinding_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_selectedArea is null)
        {
            ShowValidationMessage(
                "Select an inspection area.");
            return;
        }

        if (_selectedImage is null)
        {
            ShowValidationMessage(
                "Select an image.");
            return;
        }

        if (SelectionRectangle.Visibility !=
                Visibility.Visible)
        {
            ShowValidationMessage(
                "Draw a rectangle.");
            return;
        }

        var damageType =
            GetSelectedComboBoxValue(
                DamageTypeComboBox);

        var severity =
            GetSelectedComboBoxValue(
                SeverityComboBox);

        var description =
            DescriptionTextBox.Text.Trim();

        var finding =
            new FindingRecord
            {
                InspectionArea =
                    _selectedArea.AreaName,

                Component =
                    _selectedArea.AreaName,

                SourceImagePath =
                    _selectedImage.FullPath,

                SourceImageFileName =
                    _selectedImage.FileName,

                DamageType =
                    damageType,

                Severity =
                    severity,

                Description =
                    description,

                SelectionX =
                    GetRectangleLeft(),

                SelectionY =
                    GetRectangleTop(),

                SelectionWidth =
                    SelectionRectangle.Width,

                SelectionHeight =
                    SelectionRectangle.Height
            };

        try
        {
            var evidenceFolder =
                Path.Combine(
                    Path.GetDirectoryName(
                        finding.SourceImagePath)!,
                    "CT Borescope Reports",
                    "Finding Evidence");

            var evidenceResult =
                _imageAnnotationService
                    .CreateFindingEvidence(
                        finding.SourceImagePath,
                        evidenceFolder,
                        finding.FindingId,
                        finding.SelectionX,
                        finding.SelectionY,
                        finding.SelectionWidth,
                        finding.SelectionHeight,
                        SelectionCanvas.ActualWidth,
                        SelectionCanvas.ActualHeight);

            finding.AnnotatedImagePath =
                evidenceResult.AnnotatedImagePath;

            finding.ZoomImagePath =
                evidenceResult.ZoomImagePath;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.ToString(),
                "Evidence Generation Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return;
        }

  _findings.Add(
    finding);

var reportsFolder =
    Path.Combine(
        Path.GetDirectoryName(
            finding.SourceImagePath)!,
        "CT Borescope Reports");

Directory.CreateDirectory(
    reportsFolder);

var findingsJsonPath =
    Path.Combine(
        reportsFolder,
        "Findings.json");

_findingRepository.SaveFindings(
    findingsJsonPath,
    _findings);

FindingsListBox.Items.Add(
    BuildFindingDisplayText(
        finding,
        _findings.Count));

        MessageBox.Show(
            $"Finding {_findings.Count} created." +
            Environment.NewLine +
            Environment.NewLine +
            $"Area: {finding.InspectionArea}" +
            Environment.NewLine +
            $"Image: {finding.SourceImageFileName}" +
            Environment.NewLine +
            $"Damage: {finding.DamageType}" +
            Environment.NewLine +
            $"Severity: {finding.Severity}" +
            Environment.NewLine +
            Environment.NewLine +
            $"Annotated:" +
            Environment.NewLine +
            $"{finding.AnnotatedImagePath}" +
            Environment.NewLine +
            Environment.NewLine +
            $"Zoom:" +
            Environment.NewLine +
            $"{finding.ZoomImagePath}",
            "CT Borescope Process Tool",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        DescriptionTextBox.Clear();

        DamageTypeComboBox.SelectedIndex =
            -1;

        SeverityComboBox.SelectedIndex =
            -1;

        ResetSelection();
    }

    private void ResetSelection()
    {
        SelectionRectangle.Visibility =
            Visibility.Collapsed;

        SelectionRectangle.Width =
            0;

        SelectionRectangle.Height =
            0;

        CoordinateTextBlock.Text =
            "Rectangle: None";
    }

    private void UpdateCoordinateDisplay(
        double left,
        double top,
        double width,
        double height)
    {
        CoordinateTextBlock.Text =
            $"Rectangle: X={left:0} " +
            $"Y={top:0} " +
            $"W={width:0} " +
            $"H={height:0}";
    }

    private double GetRectangleLeft()
    {
        var value =
            Canvas.GetLeft(
                SelectionRectangle);

        return double.IsNaN(value)
            ? 0
            : value;
    }

    private double GetRectangleTop()
    {
        var value =
            Canvas.GetTop(
                SelectionRectangle);

        return double.IsNaN(value)
            ? 0
            : value;
    }

    private static string GetSelectedComboBoxValue(
        ComboBox comboBox)
    {
        if (comboBox.SelectedItem
            is not ComboBoxItem item)
        {
            return "";
        }

        return item.Content?.ToString()
            ?? "";
    }

    private static string BuildFindingDisplayText(
        FindingRecord finding,
        int findingNumber)
    {
        return
            $"#{findingNumber} " +
            $"{finding.DamageType} | " +
            $"{finding.Severity}" +
            Environment.NewLine +
            $"{finding.InspectionArea} | " +
            $"{finding.SourceImageFileName}";
    }

    private static void ShowValidationMessage(
        string message)
    {
        MessageBox.Show(
            message,
            "Finding Review",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void Close_Click(
        object sender,
        RoutedEventArgs e)
    {
        Close();
    }
}
