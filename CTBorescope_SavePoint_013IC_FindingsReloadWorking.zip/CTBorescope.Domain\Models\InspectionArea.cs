namespace CTBorescope.Domain.Models;

public class InspectionArea
{
    public string AreaName { get; set; } = "";

    public int InspectionOrder { get; set; }

    public int ImageCount { get; set; }

    public int VideoCount { get; set; }

    public DateTime? FirstPhoto { get; set; }

    public DateTime? LastPhoto { get; set; }

    public TimeSpan? PhotoDuration
    {
        get
        {
            if (!FirstPhoto.HasValue ||
                !LastPhoto.HasValue)
            {
                return null;
            }

            return LastPhoto.Value -
                   FirstPhoto.Value;
        }
    }

    public List<ImageRecord> Images { get; set; } =
        new();

    public List<VideoRecord> Videos { get; set; } =
        new();
}
