﻿namespace CTBorescope.Domain;

public class Class1
{

}
