namespace CTBorescope.Domain.Models;

public class ImportSummary
{
    public string InspectionName { get; set; } = "";

    public string RootFolder { get; set; } = "";

    public int AreaCount { get; set; }

    public int ImageCount { get; set; }

    public int VideoCount { get; set; }

    public DateTime? FirstPhoto { get; set; }

    public DateTime? LastPhoto { get; set; }

    public TimeSpan? Duration
    {
        get
        {
            if (!FirstPhoto.HasValue ||
                !LastPhoto.HasValue)
            {
                return null;
            }

            return LastPhoto.Value -
                   FirstPhoto.Value;
        }
    }

    public List<InspectionArea> Areas { get; set; } =
        new();
}