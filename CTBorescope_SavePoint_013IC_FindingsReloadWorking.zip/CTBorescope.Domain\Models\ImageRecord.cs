namespace CTBorescope.Domain.Models;

public class ImageRecord
{
    public string FileName { get; set; } = "";

    public string FullPath { get; set; } = "";

    public string RelativeFolder { get; set; } = "";

    public DateTime? DateTaken { get; set; }

    public DateTime? FilenameTimestamp { get; set; }

    public DateTime CreatedDate { get; set; }

    public DateTime ModifiedDate { get; set; }

    public bool HasExifDateTaken =>
        DateTaken.HasValue;

    public bool TimestampValidated { get; set; }

    public string TimestampSource { get; set; } = "";

    public string ValidationResult { get; set; } = "";

    public string MetadataStatus { get; set; } = "";

    public long FileSizeBytes { get; set; }
}