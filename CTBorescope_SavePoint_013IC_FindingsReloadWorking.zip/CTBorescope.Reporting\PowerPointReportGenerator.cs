﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using CTBorescope.Domain.Models;

namespace CTBorescope.Reporting;

public class PowerPointReportGenerator
{
    private const int PpLayoutBlank = 12;

    private const int MsoFalse = 0;
    private const int MsoTrue = -1;
    private const int MsoTextOrientationHorizontal = 1;

    private const float SlideWidth = 960.0f;
    private const float SlideHeight = 540.0f;

    private const int ColorDarkBlue = 0x783C0C;
    private const int ColorLightBlue = 0xEFD9C3;
    private const int ColorWhite = 0xFFFFFF;
    private const int ColorBlack = 0x000000;
    private const int ColorGray = 0x666666;
    private const int ColorLightGray = 0xF2F2F2;

    private const int AreasPerInventorySlide = 8;

    public string GeneratePowerPoint(
        ImportSummary summary)
    {
        ArgumentNullException.ThrowIfNull(summary);

        ValidateSummary(summary);

        var powerPointType =
            Type.GetTypeFromProgID(
                "PowerPoint.Application");

        if (powerPointType is null)
        {
            throw new InvalidOperationException(
                "Microsoft PowerPoint is not installed or unavailable.");
        }

        var reportFolder =
            GetReportFolder(summary);

        var safeInspectionName =
            CreateSafeFileName(
                summary.InspectionName);

        var outputPath =
            Path.Combine(
                reportFolder,
                $"{safeInspectionName}_" +
                $"Borescope_Inspection_" +
                $"{DateTime.Now:yyyyMMdd_HHmmss}.pptx");

        dynamic? powerPointApplication = null;
        dynamic? presentation = null;

        try
        {
            powerPointApplication =
                Activator.CreateInstance(
                    powerPointType);

            if (powerPointApplication is null)
            {
                throw new InvalidOperationException(
                    "Microsoft PowerPoint could not be started.");
            }

            powerPointApplication.Visible =
                MsoTrue;

            presentation =
                powerPointApplication
                    .Presentations
                    .Add(MsoTrue);

            presentation.PageSetup.SlideWidth =
                SlideWidth;

            presentation.PageSetup.SlideHeight =
                SlideHeight;

            AddTitleSlide(
                presentation,
                summary);

            AddExecutiveSummarySlide(
                presentation,
                summary);

            AddTimelineSlide(
                presentation,
                summary);

            AddInspectionInventorySlides(
                presentation,
                summary);

            foreach (var area in summary.Areas)
            {
                AddInspectionAreaSlide(
                    presentation,
                    area);
            }

            AddVideoInventorySlide(
                presentation,
                summary);

            AddLimitationsSlide(
                presentation);

            presentation.SaveAs(
                outputPath);

            return outputPath;
        }
        finally
        {
            if (presentation is not null)
            {
                try
                {
                    presentation.Close();
                }
                catch
                {
                }

                ReleaseComObject(
                    presentation);
            }

            if (powerPointApplication is not null)
            {
                try
                {
                    powerPointApplication.Quit();
                }
                catch
                {
                }

                ReleaseComObject(
                    powerPointApplication);
            }

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    private static void AddTitleSlide(
        dynamic presentation,
        ImportSummary summary)
    {
        dynamic slide =
            presentation.Slides.Add(
                presentation.Slides.Count + 1,
                PpLayoutBlank);

        AddBackground(
            slide,
            ColorDarkBlue);

        AddTextBox(
            slide,
            summary.InspectionName,
            70,
            120,
            820,
            85,
            30,
            true,
            ColorWhite);

        AddTextBox(
            slide,
            "CT Borescope Inspection Report",
            70,
            220,
            820,
            55,
            22,
            false,
            ColorLightBlue);

        AddTextBox(
            slide,
            $"Inspection evidence: " +
            $"{summary.ImageCount} images, " +
            $"{summary.VideoCount} videos",
            70,
            300,
            820,
            40,
            17,
            false,
            ColorWhite);

        AddTextBox(
            slide,
            $"Capture range: " +
            $"{FormatDate(summary.FirstPhoto)} to " +
            $"{FormatDate(summary.LastPhoto)}",
            70,
            350,
            820,
            45,
            15,
            false,
            ColorWhite);

        AddFooter(
            slide,
            "Generated by CT Borescope Process Tool");
    }

    private static void AddExecutiveSummarySlide(
        dynamic presentation,
        ImportSummary summary)
    {
        dynamic slide =
            CreateContentSlide(
                presentation,
                "Inspection Summary");

        var imagesWithExif =
            summary.Areas
                .SelectMany(area => area.Images)
                .Count(image => image.HasExifDateTaken);

        var imagesWithoutExif =
            summary.ImageCount -
            imagesWithExif;

        var summaryText =
            $"Inspection areas: {summary.AreaCount}\n\n" +
            $"Images: {summary.ImageCount}\n\n" +
            $"Videos: {summary.VideoCount}\n\n" +
            $"Images with EXIF Date Taken: {imagesWithExif}\n\n" +
            $"Images missing EXIF Date Taken: {imagesWithoutExif}\n\n" +
            $"First photo: {FormatDate(summary.FirstPhoto)}\n\n" +
            $"Last photo: {FormatDate(summary.LastPhoto)}\n\n" +
            $"Overall capture span: " +
            $"{FormatDuration(summary.Duration)}";

        AddPanel(
            slide,
            55,
            110,
            850,
            350,
            ColorLightGray);

        AddTextBox(
            slide,
            summaryText,
            85,
            135,
            790,
            300,
            18,
            false,
            ColorBlack);

        AddFooter(
            slide,
            "Summary is based on the contractor folder structure " +
            "and available image metadata.");
    }

    private static void AddTimelineSlide(
        dynamic presentation,
        ImportSummary summary)
    {
        dynamic slide =
            CreateContentSlide(
                presentation,
                "Capture Timeline");

        var sequenceText =
            string.Join(
                "\n",
                summary.Areas
                    .Take(14)
                    .Select(
                        area =>
                            $"#{area.InspectionOrder}  " +
                            $"{area.AreaName}  |  " +
                            $"{FormatShortDate(area.FirstPhoto)}"));

        if (summary.Areas.Count > 14)
        {
            sequenceText +=
                $"\n\nAdditional areas: " +
                $"{summary.Areas.Count - 14}";
        }

        AddPanel(
            slide,
            45,
            110,
            330,
            350,
            ColorLightGray);

        AddTextBox(
            slide,
            $"Inspection capture span\n\n" +
            $"{FormatDate(summary.FirstPhoto)}\n\n" +
            $"through\n\n" +
            $"{FormatDate(summary.LastPhoto)}\n\n" +
            $"Elapsed span\n\n" +
            $"{FormatDuration(summary.Duration)}",
            70,
            135,
            280,
            300,
            17,
            false,
            ColorBlack);

        AddPanel(
            slide,
            400,
            110,
            515,
            350,
            ColorLightGray);

        AddTextBox(
            slide,
            sequenceText,
            425,
            130,
            465,
            310,
            14,
            false,
            ColorBlack);

        AddFooter(
            slide,
            "Sequence uses each area's earliest available " +
            "EXIF Date Taken value.");
    }

    private static void AddInspectionInventorySlides(
        dynamic presentation,
        ImportSummary summary)
    {
        var areaChunks =
            summary.Areas
                .Select(
                    (area, index) =>
                        new
                        {
                            Area = area,
                            Index = index
                        })
                .GroupBy(
                    item =>
                        item.Index /
                        AreasPerInventorySlide)
                .Select(
                    group =>
                        group
                            .Select(item => item.Area)
                            .ToList())
                .ToList();

        for (var pageIndex = 0;
             pageIndex < areaChunks.Count;
             pageIndex++)
        {
            AddInspectionInventorySlide(
                presentation,
                areaChunks[pageIndex],
                pageIndex + 1,
                areaChunks.Count);
        }
    }

    private static void AddInspectionInventorySlide(
        dynamic presentation,
        List<InspectionArea> areas,
        int pageNumber,
        int pageCount)
    {
        var title =
            pageCount > 1
                ? $"Inspection Area Inventory " +
                  $"({pageNumber} of {pageCount})"
                : "Inspection Area Inventory";

        dynamic slide =
            CreateContentSlide(
                presentation,
                title);

        var leftAreas =
            areas
                .Take(4)
                .ToList();

        var rightAreas =
            areas
                .Skip(4)
                .Take(4)
                .ToList();

        AddInventoryPanel(
            slide,
            leftAreas,
            55,
            115,
            405,
            335);

        AddInventoryPanel(
            slide,
            rightAreas,
            500,
            115,
            405,
            335);

        AddFooter(
            slide,
            "Folder name is treated as the authoritative " +
            "inspection-area assignment.");
    }

    private static void AddInventoryPanel(
        dynamic slide,
        List<InspectionArea> areas,
        float left,
        float top,
        float width,
        float height)
    {
        AddPanel(
            slide,
            left,
            top,
            width,
            height,
            ColorLightGray);

        if (areas.Count == 0)
        {
            return;
        }

        var rowHeight =
            72.0f;

        for (var index = 0;
             index < areas.Count;
             index++)
        {
            var area =
                areas[index];

            var itemTop =
                top +
                18 +
                (index * rowHeight);

            AddTextBox(
                slide,
                $"#{area.InspectionOrder} " +
                $"{area.AreaName}\n" +
                $"Images {area.ImageCount} | " +
                $"Videos {area.VideoCount}",
                left + 25,
                itemTop,
                width - 50,
                58,
                14,
                false,
                ColorBlack);
        }
    }

    private static void AddInspectionAreaSlide(
        dynamic presentation,
        InspectionArea area)
    {
        dynamic slide =
            CreateContentSlide(
                presentation,
                $"#{area.InspectionOrder} {area.AreaName}");

        var representativeImage =
            SelectRepresentativeImage(
                area);

        if (representativeImage is not null)
        {
            AddImagePreservingAspectRatio(
                slide,
                representativeImage.FullPath,
                45,
                115,
                555,
                330);

            AddTextBox(
                slide,
                representativeImage.FileName,
                45,
                455,
                555,
                28,
                12,
                false,
                ColorGray);
        }
        else
        {
            AddPanel(
                slide,
                45,
                115,
                555,
                330,
                ColorLightGray);

            AddTextBox(
                slide,
                "No supported representative image available.",
                85,
                245,
                475,
                55,
                18,
                false,
                ColorGray);
        }

        var areaSummary =
            $"Images: {area.ImageCount}\n" +
            $"Videos: {area.VideoCount}\n\n" +
            $"First photo:\n" +
            $"{FormatDate(area.FirstPhoto)}\n\n" +
            $"Last photo:\n" +
            $"{FormatDate(area.LastPhoto)}\n\n" +
            $"Photo span:\n" +
            $"{FormatDuration(area.PhotoDuration)}";

        AddPanel(
            slide,
            625,
            115,
            290,
            330,
            ColorLightGray);

        AddTextBox(
            slide,
            areaSummary,
            650,
            140,
            240,
            280,
            17,
            false,
            ColorBlack);

        AddFooter(
            slide,
            "Representative image shown for inventory context. " +
            "No engineering disposition is assigned.");
    }

    private static void AddVideoInventorySlide(
        dynamic presentation,
        ImportSummary summary)
    {
        dynamic slide =
            CreateContentSlide(
                presentation,
                "Supplemental Video Documentation");

        var videos =
            summary.Areas
                .SelectMany(
                    area =>
                        area.Videos.Select(
                            video =>
                                new
                                {
                                    AreaName =
                                        area.AreaName,

                                    Video =
                                        video
                                }))
                .ToList();

        if (videos.Count == 0)
        {
            AddTextBox(
                slide,
                "No supported video files were identified.",
                75,
                180,
                810,
                70,
                23,
                false,
                ColorGray);
        }
        else
        {
            var videoText =
                string.Join(
                    "\n\n",
                    videos.Select(
                        item =>
                            $"{item.AreaName}\n" +
                            $"  {item.Video.FileName}"));

            AddPanel(
                slide,
                55,
                110,
                850,
                340,
                ColorLightGray);

            AddTextBox(
                slide,
                videoText,
                85,
                135,
                790,
                290,
                16,
                false,
                ColorBlack);
        }

        AddFooter(
            slide,
            "Videos are supplemental documentation and are " +
            "excluded from the AI still-image review queue.");
    }

    private static void AddLimitationsSlide(
        dynamic presentation)
    {
        dynamic slide =
            CreateContentSlide(
                presentation,
                "Review Limitations and Closeout");

        var limitationText =
            "- Folder names are treated as the authoritative " +
            "inspection-area assignment.\n\n" +

            "- Source filenames and original-resolution files " +
            "must be retained.\n\n" +

            "- A single image cannot confirm crack depth, " +
            "subsurface distress, dimensions, or remaining life.\n\n" +

            "- AI screening and visible observations are " +
            "inspection-review aids only.\n\n" +

            "- Final disposition requires the applicable procedure, " +
            "service history, comparison images, measurements when " +
            "available, engineering review, and OEM acceptance criteria.\n\n" +

            "- No image-only result constitutes equipment acceptance " +
            "or return-to-service approval.";

        AddPanel(
            slide,
            55,
            105,
            850,
            360,
            ColorLightGray);

        AddTextBox(
            slide,
            limitationText,
            80,
            125,
            800,
            315,
            17,
            false,
            ColorBlack);

        AddFooter(
            slide,
            "Record confirmed findings, source filenames, measurements, " +
            "disposition, corrective action, and monitoring requirements.");
    }

    private static dynamic CreateContentSlide(
        dynamic presentation,
        string title)
    {
        dynamic slide =
            presentation.Slides.Add(
                presentation.Slides.Count + 1,
                PpLayoutBlank);

        AddBackground(
            slide,
            ColorWhite);

        dynamic header =
            slide.Shapes.AddShape(
                1,
                0,
                0,
                SlideWidth,
                82);

        header.Fill.ForeColor.RGB =
            ColorDarkBlue;

        header.Line.Visible =
            MsoFalse;

        AddTextBox(
            slide,
            title,
            40,
            18,
            875,
            48,
            26,
            true,
            ColorWhite);

        return slide;
    }

    private static void AddBackground(
        dynamic slide,
        int color)
    {
        slide.FollowMasterBackground =
            MsoFalse;

        slide.Background.Fill.ForeColor.RGB =
            color;

        slide.Background.Fill.Solid();
    }

    private static void AddPanel(
        dynamic slide,
        float left,
        float top,
        float width,
        float height,
        int color)
    {
        dynamic panel =
            slide.Shapes.AddShape(
                1,
                left,
                top,
                width,
                height);

        panel.Fill.ForeColor.RGB =
            color;

        panel.Line.ForeColor.RGB =
            ColorLightBlue;
    }

    private static void AddTextBox(
        dynamic slide,
        string text,
        float left,
        float top,
        float width,
        float height,
        float fontSize,
        bool bold,
        int color)
    {
        dynamic textBox =
            slide.Shapes.AddTextbox(
                MsoTextOrientationHorizontal,
                left,
                top,
                width,
                height);

        textBox.TextFrame.TextRange.Text =
            text;

        textBox.TextFrame.TextRange.Font.Name =
            "Aptos";

        textBox.TextFrame.TextRange.Font.Size =
            fontSize;

        textBox.TextFrame.TextRange.Font.Bold =
            bold
                ? MsoTrue
                : MsoFalse;

        textBox.TextFrame.TextRange.Font.Color.RGB =
            color;

        textBox.TextFrame.WordWrap =
            MsoTrue;

        textBox.TextFrame.AutoSize =
            0;
    }

    private static void AddFooter(
        dynamic slide,
        string text)
    {
        AddTextBox(
            slide,
            text,
            40,
            505,
            880,
            24,
            10,
            false,
            ColorGray);
    }

    private static ImageRecord? SelectRepresentativeImage(
        InspectionArea area)
    {
        var displayableImageExtensions =
            new[]
            {
                ".jpg",
                ".jpeg",
                ".png",
                ".bmp"
            };

        var timestampedImages =
            area.Images
                .Where(
                    image =>
                        displayableImageExtensions.Contains(
                            Path.GetExtension(
                                image.FullPath),
                            StringComparer.OrdinalIgnoreCase))
                .Where(
                    image =>
                        image.DateTaken.HasValue)
                .OrderBy(
                    image =>
                        image.DateTaken!.Value)
                .ToList();

        if (timestampedImages.Count > 0)
        {
            var middleIndex =
                timestampedImages.Count /
                2;

            return timestampedImages[
                middleIndex];
        }

        var displayableImages =
            area.Images
                .Where(
                    image =>
                        displayableImageExtensions.Contains(
                            Path.GetExtension(
                                image.FullPath),
                            StringComparer.OrdinalIgnoreCase))
                .OrderBy(
                    image =>
                        image.FileName,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();

        if (displayableImages.Count == 0)
        {
            return null;
        }

        return displayableImages[
            displayableImages.Count / 2];
    }

    private static void AddImagePreservingAspectRatio(
        dynamic slide,
        string imagePath,
        float left,
        float top,
        float maxWidth,
        float maxHeight)
    {
        if (!File.Exists(imagePath))
        {
            return;
        }

        dynamic picture =
            slide.Shapes.AddPicture(
                imagePath,
                MsoFalse,
                MsoTrue,
                left,
                top,
                -1,
                -1);

        var widthRatio =
            maxWidth /
            (float)picture.Width;

        var heightRatio =
            maxHeight /
            (float)picture.Height;

        var scale =
            Math.Min(
                widthRatio,
                heightRatio);

        picture.Width =
            picture.Width * scale;

        picture.Height =
            picture.Height * scale;

        picture.Left =
            left +
            ((maxWidth - picture.Width) / 2);

        picture.Top =
            top +
            ((maxHeight - picture.Height) / 2);
    }

    private static string FormatDate(
        DateTime? date)
    {
        return date.HasValue
            ? date.Value.ToString(
                "MM/dd/yyyy h:mm:ss tt")
            : "Not available";
    }

    private static string FormatShortDate(
        DateTime? date)
    {
        return date.HasValue
            ? date.Value.ToString(
                "MM/dd h:mm tt")
            : "No EXIF timestamp";
    }

    private static string FormatDuration(
        TimeSpan? duration)
    {
        if (!duration.HasValue)
        {
            return "Not available";
        }

        var value =
            duration.Value;

        return
            $"{(int)value.TotalHours}h " +
            $"{value.Minutes}m " +
            $"{value.Seconds}s";
    }

    private static string CreateSafeFileName(
        string value)
    {
        var safeName =
            value;

        foreach (var invalidCharacter
                 in Path.GetInvalidFileNameChars())
        {
            safeName =
                safeName.Replace(
                    invalidCharacter,
                    '_');
        }

        return string.IsNullOrWhiteSpace(safeName)
            ? "CT_Borescope"
            : safeName;
    }

    private static string GetReportFolder(
        ImportSummary summary)
    {
        var reportFolder =
            Path.Combine(
                summary.RootFolder,
                "CT Borescope Reports");

        Directory.CreateDirectory(
            reportFolder);

        return reportFolder;
    }

    private static void ValidateSummary(
        ImportSummary summary)
    {
        if (string.IsNullOrWhiteSpace(
                summary.RootFolder))
        {
            throw new InvalidOperationException(
                "The inspection root folder is unavailable.");
        }

        if (!Directory.Exists(
                summary.RootFolder))
        {
            throw new DirectoryNotFoundException(
                "The inspection root folder does not exist.");
        }

        if (summary.Areas.Count == 0)
        {
            throw new InvalidOperationException(
                "No inspection areas are available.");
        }
    }

    private static void ReleaseComObject(
        object? comObject)
    {
        if (comObject is null)
        {
            return;
        }

        try
        {
            if (Marshal.IsComObject(comObject))
            {
                Marshal.FinalReleaseComObject(
                    comObject);
            }
        }
        catch
        {
        }
    }
}