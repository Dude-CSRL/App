﻿namespace CTBorescope.Infrastructure;

public class Class1
{

}
