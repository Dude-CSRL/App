using System;
using System.IO;
using System.Linq;
using System.Text;
using CTBorescope.Domain.Models;

namespace CTBorescope.Reporting;

public class InspectionReportGenerator
{
    public string GenerateReport(
        ImportSummary summary)
    {
        ArgumentNullException.ThrowIfNull(summary);

        if (string.IsNullOrWhiteSpace(summary.RootFolder))
        {
            throw new InvalidOperationException(
                "The inspection root folder is not available.");
        }

        if (!Directory.Exists(summary.RootFolder))
        {
            throw new DirectoryNotFoundException(
                "The inspection root folder does not exist.");
        }

        var reportFolder =
            Path.Combine(
                summary.RootFolder,
                "CT Borescope Reports");

        Directory.CreateDirectory(
            reportFolder);

        var safeInspectionName =
            CreateSafeFileName(
                summary.InspectionName);

        var reportFileName =
            $"{safeInspectionName}_" +
            $"Inspection_Report_" +
            $"{DateTime.Now:yyyyMMdd_HHmmss}.md";

        var reportPath =
            Path.Combine(
                reportFolder,
                reportFileName);

        var reportText =
            BuildReportText(summary);

        File.WriteAllText(
            reportPath,
            reportText,
            Encoding.UTF8);

        return reportPath;
    }

    private static string BuildReportText(
        ImportSummary summary)
    {
        var report =
            new StringBuilder();

        var allImages =
            summary.Areas
                .SelectMany(area => area.Images)
                .ToList();

        var imagesWithExif =
            allImages.Count(
                image => image.HasExifDateTaken);

        var imagesWithoutExif =
            allImages.Count(
                image => !image.HasExifDateTaken);

        report.AppendLine(
            $"# {summary.InspectionName}");

        report.AppendLine();

        report.AppendLine(
            "## CT Borescope Inspection Report");

        report.AppendLine();

        report.AppendLine(
            $"**Report generated:** " +
            $"{DateTime.Now:MM/dd/yyyy h:mm:ss tt}");

        report.AppendLine();

        report.AppendLine(
            $"**Inspection source folder:** " +
            $"{summary.RootFolder}");

        report.AppendLine();

        report.AppendLine(
            "## Review Purpose and Limitations");

        report.AppendLine();

        report.AppendLine(
            "This report inventories the imported borescope " +
            "inspection evidence and reconstructs the available " +
            "capture sequence from image metadata.");

        report.AppendLine();

        report.AppendLine(
            "Folder names are treated as the authoritative " +
            "inspection-area assignment because the reviewer " +
            "was not present while the contractor captured " +
            "the inspection media.");

        report.AppendLine();

        report.AppendLine(
            "Visible observations and future AI screening are " +
            "inspection-review aids only. Final engineering " +
            "disposition must use original-resolution files, " +
            "inspection procedures, service history, comparison " +
            "images, measurements when available, and applicable " +
            "OEM acceptance criteria.");

        report.AppendLine();

        report.AppendLine(
            "No image-only result constitutes equipment acceptance, " +
            "remaining-life determination, or return-to-service approval.");

        report.AppendLine();

        report.AppendLine(
            "## Executive Summary");

        report.AppendLine();

        report.AppendLine(
            $"| Field | Value |");

        report.AppendLine(
            $"|---|---|");

        report.AppendLine(
            $"| Inspection | {summary.InspectionName} |");

        report.AppendLine(
            $"| Inspection areas | {summary.AreaCount} |");

        report.AppendLine(
            $"| Images | {summary.ImageCount} |");

        report.AppendLine(
            $"| Videos | {summary.VideoCount} |");

        report.AppendLine(
            $"| Images with EXIF Date Taken | " +
            $"{imagesWithExif} |");

        report.AppendLine(
            $"| Images missing EXIF Date Taken | " +
            $"{imagesWithoutExif} |");

        report.AppendLine(
            $"| First photo | " +
            $"{FormatDate(summary.FirstPhoto)} |");

        report.AppendLine(
            $"| Last photo | " +
            $"{FormatDate(summary.LastPhoto)} |");

        report.AppendLine(
            $"| Inspection time span | " +
            $"{FormatDuration(summary.Duration)} |");

        report.AppendLine();

        report.AppendLine(
            "## Inspection Sequence");

        report.AppendLine();

        report.AppendLine(
            "| Order | Inspection Area | Images | Videos | " +
            "First Photo | Last Photo | Photo Duration |");

        report.AppendLine(
            "|---:|---|---:|---:|---|---|---|");

        foreach (var area in summary.Areas)
        {
            report.AppendLine(
                $"| {area.InspectionOrder} " +
                $"| {EscapeTableText(area.AreaName)} " +
                $"| {area.ImageCount} " +
                $"| {area.VideoCount} " +
                $"| {FormatDate(area.FirstPhoto)} " +
                $"| {FormatDate(area.LastPhoto)} " +
                $"| {FormatDuration(area.PhotoDuration)} |");
        }

        report.AppendLine();

        report.AppendLine(
            "## Inspection Area Details");

        foreach (var area in summary.Areas)
        {
            AppendAreaSection(
                report,
                area);
        }

        report.AppendLine();

        report.AppendLine(
            "## Metadata Coverage");

        report.AppendLine();

        if (imagesWithoutExif == 0)
        {
            report.AppendLine(
                "All imported images contain an EXIF Date Taken value.");
        }
        else
        {
            report.AppendLine(
                $"{imagesWithoutExif} imported images do not contain " +
                "an EXIF Date Taken value. These images remain part " +
                "of the inspection evidence, but they are excluded " +
                "from EXIF-based sequence and duration calculations.");
        }

        report.AppendLine();

        report.AppendLine(
            "## Video Handling");

        report.AppendLine();

        if (summary.VideoCount == 0)
        {
            report.AppendLine(
                "No supported video files were identified.");
        }
        else
        {
            report.AppendLine(
                $"{summary.VideoCount} supported video files were " +
                "identified and classified as supplemental documentation.");

            report.AppendLine();

            report.AppendLine(
                "Videos are excluded from the AI still-image review " +
                "queue. A future workflow may extract selected frames " +
                "for separate documentation review.");
        }

        report.AppendLine();

        report.AppendLine(
            "## Recommended Closeout Record");

        report.AppendLine();

        report.AppendLine(
            "For each confirmed discrepancy, record the inspection " +
            "area, source filename, discrepancy classification, visible " +
            "observation, measurements when available, engineering or " +
            "OEM disposition, corrective action, and monitoring interval.");

        return report.ToString();
    }

    private static void AppendAreaSection(
        StringBuilder report,
        InspectionArea area)
    {
        var imagesWithExif =
            area.Images.Count(
                image => image.HasExifDateTaken);

        var imagesWithoutExif =
            area.Images.Count(
                image => !image.HasExifDateTaken);

        report.AppendLine();

        report.AppendLine(
            $"### #{area.InspectionOrder} " +
            $"{area.AreaName}");

        report.AppendLine();

        report.AppendLine(
            $"- Images: {area.ImageCount}");

        report.AppendLine(
            $"- Videos: {area.VideoCount}");

        report.AppendLine(
            $"- EXIF dates found: {imagesWithExif}");

        report.AppendLine(
            $"- EXIF dates missing: {imagesWithoutExif}");

        report.AppendLine(
            $"- First photo: {FormatDate(area.FirstPhoto)}");

        report.AppendLine(
            $"- Last photo: {FormatDate(area.LastPhoto)}");

        report.AppendLine(
            $"- Photo time span: " +
            $"{FormatDuration(area.PhotoDuration)}");

        if (area.VideoCount > 0)
        {
            report.AppendLine();

            report.AppendLine(
                "**Supplemental video documentation**");

            report.AppendLine();

            foreach (var video in area.Videos)
            {
                report.AppendLine(
                    $"- {video.FileName} " +
                    $"({video.EvidenceCategory}; " +
                    $"excluded from AI image review)");
            }
        }

        report.AppendLine();

        report.AppendLine(
            "<details>");

        report.AppendLine(
            "<summary>Source image inventory</summary>");

        report.AppendLine();

        foreach (var image in area.Images)
        {
            report.AppendLine(
                $"- {image.FileName} | " +
                $"Date Taken: {FormatDate(image.DateTaken)} | " +
                $"Timestamp Source: {image.TimestampSource}");
        }

        report.AppendLine();

        report.AppendLine(
            "</details>");
    }

    private static string FormatDate(
        DateTime? date)
    {
        return date.HasValue
            ? date.Value.ToString(
                "MM/dd/yyyy h:mm:ss tt")
            : "Not available";
    }

    private static string FormatDuration(
        TimeSpan? duration)
    {
        if (!duration.HasValue)
        {
            return "Not available";
        }

        var value =
            duration.Value;

        var totalHours =
            (int)value.TotalHours;

        return
            $"{totalHours}h " +
            $"{value.Minutes}m " +
            $"{value.Seconds}s";
    }

    private static string EscapeTableText(
        string value)
    {
        return value.Replace(
            "|",
            "\\|");
    }

    private static string CreateSafeFileName(
        string value)
    {
        var safeValue =
            value;

        foreach (var invalidCharacter
                 in Path.GetInvalidFileNameChars())
        {
            safeValue =
                safeValue.Replace(
                    invalidCharacter,
                    '_');
        }

        return string.IsNullOrWhiteSpace(safeValue)
            ? "CT_Borescope"
            : safeValue;
    }
}