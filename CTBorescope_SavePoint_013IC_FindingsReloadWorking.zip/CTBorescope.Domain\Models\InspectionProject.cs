namespace CTBorescope.Domain.Models;

public class InspectionProject
{
    public string Plant { get; set; } = "";

    public string Unit { get; set; } = "";

    public string WorkOrder { get; set; } = "";

    public string Inspector { get; set; } = "";

    public string InspectionType { get; set; } = "";

    public DateTime InspectionDate { get; set; }
        = DateTime.Today;

    public DateTime? InspectionStartTime { get; set; }

    public DateTime? InspectionEndTime { get; set; }

    public string SourceFolder { get; set; } = "";
}
